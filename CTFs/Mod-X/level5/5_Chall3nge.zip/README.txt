
Agent,

You should have read the briefing by now, so you know
that your task is to examine an enemy system. I had to
think about how I was going to do this, because setting
up a server with numerous ports on the Internet and 
having it available 24/7 would not work. It would be too
expensive, and, as I am sure you will agree, it is
annoying when you HAVE to be online to do a challenge.

I spoke with a few people and we decided that this was
the best solution:

Included in this zip is "Mod5.exe". It is a server application, 
and it will operate a server on your computer - i.e. open 
ports and run daemons/services on them. This is NOT a 
trojan, and when you choose to stop running the program 
(by right clicking on its icon in the system tray) - all of the 
services will stop, and the ports will be closed.

The idea is that your computer (localhost, or 127.0.0.1) 
becomes the enemy system. So you can telnet to yourself 
and connect to your own system as if you were connecting 
to the enemy.

This has been fully tested on Windows 98/ME/NT/XP/2000, and no 
problems were encountered. It has also been tested by other 
individuals apart from myself. You may encounter a problem if 
you already run services though - so unfortunately, in this 
situation we would recommend either stopping the services 
and going offline to play - or switching to a computer without 
services running.

** NOTE **

Since this opens ports for you to connect to, this program should 
only be run when you are OFFLINE. Please make sure that you close 
the program before you go online, or else anybody on the net will 
be able to connect to your computer - and they will think they 
are real services running!

** NOTE **

To get you started - some information:

* I am not going to tell you which ports it opens, you will have to find out :)

* It only opens ports between 0 - 200 ... just to help you out.

OK, so lets say it opens Port 23 (I am not saying that it does or it doesn't 
- but for the purposes of this example) ... you could connect to yourself 
and play with the port like so:

- Go to the start menu and choose "Run"

- Type "Telnet Localhost 23"

If port 23 is then open, you will be connected to port 23, and you can have 
a play with that port and see if you can break into the enemy system :)


Good luck!

regards
Wang - wang@most-wanted.com
